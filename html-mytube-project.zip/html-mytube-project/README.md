# html-mytube-project

MyTube - A Simple HTML-Based YouTube Mockup

MyTube is a simple project that mimics the basic functionality of YouTube using only HTML. It consists of three collections, each displaying six videos, and every video has its dedicated HTML page to describe its content. Additionally, MyTube features an Upload page, allowing users to contribute their videos.